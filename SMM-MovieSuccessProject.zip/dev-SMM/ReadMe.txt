MovieSuccess.ipynb Notebook contains code to Do Analysis of Movies from 2008-16
Remainig .py files were used to scrap movie data from web

API used
-FB API
-IMDBPy API
-IMDBPie API
-moviedb API

Movie csv Folder
*facebook-movies
*google-movies
*imdb-movies
